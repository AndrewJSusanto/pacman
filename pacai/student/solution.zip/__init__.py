"""
The `pacai.student` package contains partially implemented files for students to complete for
various different assignments.
Files submitted to the autograder, will always be placed in the `pacai.student` package.
This makes it easier for the autograder, and more clear to the students.
Note that some functionality in the rest of the `pacai` package will depend on implementations
from this package.
"""
